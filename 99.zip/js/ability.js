window.ability={"passport":{"auth":{"login":function (data) {
        kiwi.call('passport', 'auth', 'login', data);
    }}},"base":{"device":{"getDevice":function (data) {
        kiwi.call("base", "device", "getDevice", data);
    }},"storage":{"setGlobalData":function (data) {
        kiwi.call("base", "storage", "setGlobalData", data);
    },"getGlobalData":function (data) {
        kiwi.call("base", "storage", "getGlobalData", data);
    }},"localStorage":{"getItem":function (data) {
        kiwi.call("base", "localStorage", "getItem", data);
    },"removeItem":function (data) {
        kiwi.call("base", "localStorage", "removeItem", data);
    },"setItem":function (data) {
        kiwi.call("base", "localStorage", "setItem", data);
    },"clear":function (data) {
        kiwi.call("base", "localStorage", "clear", data);
    }},"sessionStorage":{"getItem":function (data) {
        kiwi.call("base", "sessionStorage", "getItem", data);
    },"removeItem":function (data) {
        kiwi.call("base", "sessionStorage", "removeItem", data);
    },"setItem":function (data) {
        kiwi.call("base", "sessionStorage", "setItem", data);
    },"clear":function (data) {
        kiwi.call("base", "sessionStorage", "clear", data);
    }}},"ui":{"navigationBar":{"setHeader":function (data) {
        kiwi.call('ui', 'navigationBar', 'setHeader', data);
    }}},"core":{"basic":{"dispatchEvent":function (data) {
        kiwi.dispatchEvent(data.eventName, data.options, data.target);
    },"on":function (message, cb) {
        kiwi.on(message, cb);
    }}},"page":{"route":{"toMiniProgram":function (data) {
        kiwi.call('page', 'route', 'toMiniProgram', data);
    },"to":function (data) {
        kiwi.call('page', 'route', 'to', data);
    },"back":function () {
        kiwi.call('page', 'route', 'back');
    },"close":function (data) {
        kiwi.call('page', 'route', 'close', data);
    }}},"network":{"http":{"getNetworkType":function (data) {
        let _data = data;
        let rsp = {
            success: function (data) {
                if (data) {
                    let response = {
                        ret: "0",
                        msg: 'success',
                        data: {
                            networkState: data.type
                        }
                    };
                    _data.success & _data.success(response);
                }
            },
            failure: _data.failure
        };
        // kiwi.call('network', 'http', 'getNetworkType', rsp)
        aladdin.call('network', 'getInfo', function (err, data) {
            if (!err) {
                let response = {
                    ret: "0",
                    msg: 'success',
                    data: {
                        networkState: data.type
                    }
                };
                _data.success & _data.success(response);
            }
        });
    }}},"screen":{"offsetScreen":{"getScreenSize":function () {
        let height = document.body.offsetHeight;
        let width = document.body.offsetWidth;
        let data = {
            width: width,
            height: height
        };
        return data;
    }}},"geo":{"location":{"getLocation":function (data) {
        kiwi.call('geo', 'location', 'getLocation', data);
    }}},"device":{"camera":{"takePhoto":function (data) {
        kiwi.call('device', 'camera', 'takePhoto', data);
    },"selectPhotos":function (data) {
        kiwi.call('device', 'camera', 'selectPhotos', data);
    }},"environment":{"getEnv":function (data) {
        kiwi.call("device", "environment", "getEnv", data);
    }}},"ai":{"faceRec":{"showFaceRec":function (data) {
        kiwi.call('ai', 'faceRec', 'showFaceRec', data);
    }}},"ocr":{"bankCard":{"scan":function (data) {
        kiwi.call('ocr', 'bankCard', 'scan', data);
    }},"idCard":{"scan":function (data) {
        kiwi.call('ocr', 'idCard', 'scan', data);
    }}}}